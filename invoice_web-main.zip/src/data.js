export const recentInvoices = [
    { invoiceNumber: 1, invoiceType: "Purchase", partyName: "Harsh Singh", totalAmount: 1000, date: new Date() },
    { invoiceNumber: 2, invoiceType: "Sales", partyName: "Ramesh Singh", totalAmount: 1000, date: new Date() },
    { invoiceNumber: 3, invoiceType: "Sales", partyName: "Kamlesh Singh", totalAmount: 1000, date: new Date() },
    { invoiceNumber: 4, invoiceType: "Purchase", partyName: "Harsh Singh", totalAmount: 1000, date: new Date() },
];
