export default function TopBar({ children }) {

    return (
        <div className="top-bar">
            {children}
        </div>
    )
}