export default function SearchBar() {
    return (
        <div className="search-bar">
            <input className="input" type="search" />
        </div>
    )
}