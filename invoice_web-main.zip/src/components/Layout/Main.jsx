export default function Main({ children }) {
    return (
        <main className="app-main">
            {children}
        </main>
    )
}