export default function Field({ children }) {
    return (
        <div className="field">
            {children}
        </div>
    )
}