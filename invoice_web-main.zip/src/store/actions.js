export const LOGIN = "login";

export const LOGOUT = "logout";

export const OPEN_DRAWER = "open-drawer";

export const CLOSE_DRAWER = "close-drawer";

export const TOGGLE_DRAWER = "toggle-drawer";

export const PDF_DOC = "pdfDoc";