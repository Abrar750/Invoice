export const BASE_URL = 'https://api.itaxeasy.com';

export const BILLSHILL_URL = 'https://zen.itaxeasy.com';